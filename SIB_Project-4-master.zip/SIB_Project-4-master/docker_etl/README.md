# docker_etl

1. Generate BigQuery Service Account and paste value to service_account.json
2. Install docker and docker compose
3. Run `docker-compose up`
