### Project 4 on examples folder inside docker-etl

Hans Valerian Lenice - SIB-6
